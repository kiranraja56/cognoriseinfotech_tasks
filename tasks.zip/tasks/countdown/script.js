
const startBtn = document.getElementById('start-btn');
const targetDateInput = document.getElementById('target-date');
const daysSpan = document.getElementById('days');
const hoursSpan = document.getElementById('hours');
const minutesSpan = document.getElementById('minutes');
const secondsSpan = document.getElementById('seconds');
const messageDiv = document.getElementById('message');

let countdownInterval;

function startCountdown() {
  const targetDateValue = targetDateInput.value;
  
  if (!targetDateValue) {
    alert('Please select a valid date and time.');
    return;
  }
  
  const targetDate = new Date(targetDateValue);
  
  if (isNaN(targetDate)) {
    alert('Invalid date format. Please try again.');
    return;
  }
  
  clearInterval(countdownInterval);
  

  updateCountdown();
  countdownInterval = setInterval(updateCountdown, 1000);
}

function updateCountdown() {
  const now = new Date().getTime();
  const targetDateValue = targetDateInput.value;
  const targetDate = new Date(targetDateValue).getTime();
  
  const distance = targetDate - now;
  
  if (distance < 0) {
    clearInterval(countdownInterval);
    messageDiv.textContent = "Countdown Complete!";
    daysSpan.textContent = '0';
    hoursSpan.textContent = '0';
    minutesSpan.textContent = '0';
    secondsSpan.textContent = '0';
    return;
  }
  

  const days = Math.floor(distance / (1000 * 60 * 60 * 24));
  const hours = Math.floor((distance % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((distance % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((distance % (1000 * 60)) / 1000);
  

  daysSpan.textContent = days;
  hoursSpan.textContent = hours;
  minutesSpan.textContent = minutes;
  secondsSpan.textContent = seconds;
}


startBtn.addEventListener('click', startCountdown);
